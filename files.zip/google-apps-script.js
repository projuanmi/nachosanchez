// ═══════════════════════════════════════════════════════════
//  GOOGLE APPS SCRIPT — Backend para la encuesta de música
//  Proyecto: La Música en Nuestra Vida Diaria · 2º ESO
// ═══════════════════════════════════════════════════════════
//
//  INSTRUCCIONES:
//  1. Ve a https://script.google.com
//  2. Crea un nuevo proyecto ("Nuevo script")
//  3. Borra todo el código existente y pega ESTE archivo completo
//  4. Guarda (Ctrl+S) y ponle un nombre al proyecto
//  5. Haz clic en "Implementar" > "Nueva implementación"
//  6. Tipo: "Aplicación web"
//  7. Ejecutar como: "Yo"
//  8. Quién tiene acceso: "Cualquier usuario"
//  9. Haz clic en "Implementar" y copia la URL que te da
// 10. Pega esa URL en el index.html donde pone SCRIPT_URL
//
// ═══════════════════════════════════════════════════════════

const SHEET_NAME = 'Respuestas';

// Cabeceras de la hoja de cálculo
const HEADERS = [
  'Timestamp',
  'Edad',
  'Curso',
  'Género',
  'Género Musical',
  'Horas de Música/día',
  'Efectos de la Música',
  'Cree que la música afecta a las plantas',
  'Música preferida para las plantas',
  'Interés por la Ciencia (1-10)',
  'Plantas en Casa',
  'Comentario'
];

// ─── Función para recibir respuestas (POST) ───────────────
function doPost(e) {
  try {
    const sheet = getOrCreateSheet();
    const data = JSON.parse(e.postData.contents);

    const row = [
      data.timestamp,
      data.edad,
      data.curso,
      data.genero,
      data.genero_musical,
      data.horas_musica,
      data.efectos,
      data.creencia,
      data.planta_musica,
      data.interes_ciencia,
      data.plantas_casa,
      data.comentario
    ];

    sheet.appendRow(row);

    return ContentService
      .createTextOutput(JSON.stringify({ success: true, message: 'Respuesta guardada' }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ─── Función para leer respuestas (GET) ───────────────────
function doGet(e) {
  try {
    const sheet = getOrCreateSheet();
    const rows = sheet.getDataRange().getValues();

    // Saltamos la fila de cabeceras
    const data = rows.slice(1).map(row => ({
      timestamp:       row[0],
      edad:            row[1],
      curso:           row[2],
      genero:          row[3],
      genero_musical:  row[4],
      horas_musica:    row[5],
      efectos:         row[6],
      creencia:        row[7],
      planta_musica:   row[8],
      interes_ciencia: row[9],
      plantas_casa:    row[10],
      comentario:      row[11]
    }));

    return ContentService
      .createTextOutput(JSON.stringify({ success: true, data: data, total: data.length }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: err.toString(), data: [] }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ─── Helper: obtener o crear la hoja ──────────────────────
function getOrCreateSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);

  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(HEADERS);

    // Formato de cabeceras
    const headerRange = sheet.getRange(1, 1, 1, HEADERS.length);
    headerRange.setBackground('#2d6a4f');
    headerRange.setFontColor('#ffffff');
    headerRange.setFontWeight('bold');
    sheet.setFrozenRows(1);
  }

  return sheet;
}
